from learncrypy import *

class Utils:
    pass