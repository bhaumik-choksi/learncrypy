from learncrypy import *

class Hashes:
    pass